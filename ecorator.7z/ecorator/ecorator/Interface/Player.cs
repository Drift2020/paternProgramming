﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ecorator
{
    interface Player
    {
         string NameF();
         int HitpontsF();
        int SpeedF();
        int DamageF();
        int DefenseF();
    }
}
