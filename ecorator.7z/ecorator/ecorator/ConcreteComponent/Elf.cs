﻿using ecorator.Component;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ecorator.ConcreteComponent
{
    class Elf: Being_Magic
    {
     

            public Elf() : base("Эльф",100,
               30, 15, 0)
            {

            }

          
        
    }
}
