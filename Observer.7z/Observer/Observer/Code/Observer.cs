﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Observer.Code
{
    public abstract class Observer
    {
        public abstract void Update();
        public abstract void Activ_text();
    }
}
