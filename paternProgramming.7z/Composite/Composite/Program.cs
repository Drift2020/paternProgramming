﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Composite
{



    class Program
    {
        class Arhitect
        {
            public Arhitect()
            {
                my_tree = new List<Root>();
                map_in_my_tree = new List<string>();

                Root root = new Trunk("root",0,new ConsoleWriter());

                root.Add(new Trunk("File A", 0, new ConsoleWriter()), new string[] { "1" });
                root.Add(new Trunk("File B", 0, new ConsoleWriter()), new string[] { "1" });

                Root comp = new Trunk("Folder X", 0, new ConsoleWriter());

                comp.Add(new Trunk("File XA", 0, new ConsoleWriter()), new string[] { "1" });
                comp.Add(new Trunk("File XB", 0, new ConsoleWriter()), new string[] { "1" });
                root.Add(comp, new string[] { "1" });

                Root comp2 = new Trunk("Folder Y", 0, new ConsoleWriter());

                comp2.Add(new Trunk("File YA", 0, new ConsoleWriter()), new string[] { "1" });
                comp2.Add(new Trunk("File YB", 0, new ConsoleWriter()), new string[] { "1" });

                Root comp3 = new Trunk("Folder Z", 0, new ConsoleWriter());
                comp3.Add(new Trunk("File YZA", 0, new ConsoleWriter()), new string[] { "1" });
                comp3.Add(new Trunk("File YZB", 0, new ConsoleWriter()), new string[] { "1" });
                comp2.Add(comp3, new string[] { "1" });

                root.Add(comp2, new string[] { "1" });

                root.Add(new Trunk("File C", 0, new ConsoleWriter()), new string[] { "1" });

                Root leaf = new Trunk("File D", 0, new ConsoleWriter());
                root.Add(leaf, new string[] { "1" });
                my_tree.Add(root);
            }
            List<Root> my_tree;
            public List<string> map_in_my_tree=new List<string>();


            public void Add(string elem,int my_price)
            {
                if (map_in_my_tree.Count>0)
                {
                    int number = Convert.ToInt32(map_in_my_tree[0]);
                    my_tree[number-1].Add(new Trunk(elem, my_price, new ConsoleWriter()), map_in_my_tree.ToArray());
                }
               
                else
                    my_tree.Add(new Trunk(elem, my_price, new ConsoleWriter()));
            }
         
            public void Remove()
            {
                if(map_in_my_tree.Count==1)
                {
                    int number = Convert.ToInt32(map_in_my_tree[0]);
                    my_tree.RemoveAt(number-1);
                }
                else if(map_in_my_tree.Count > 0)
                {
                    int number = Convert.ToInt32(map_in_my_tree[0]);

                    string[] temp = new string[map_in_my_tree.ToArray().Length - 1];
                    Array.Copy(map_in_my_tree.ToArray(), 1, temp, 0, map_in_my_tree.ToArray().Length - 1);

                    my_tree[number - 1].Remove(temp.ToArray());
                }

                else
                    my_tree.Clear();
            }
            public void Display()
            {
                for (int i = 0; i < my_tree.Count; i++)
                {
                    my_tree[i].Display("\t "+i.ToString());
                }
            }
        }
        static void Main(string[] args)
        {
            Arhitect my_tree=new Arhitect();
            int chose = 0;
            while (true)
            {
                my_tree.Display();
                Console.WriteLine("Map in you tree");
                my_tree.map_in_my_tree.ForEach(elem => { Console.Write(elem + " "); });
                Console.Write("\n\n");
                Console.Write("1.Go to the branch\n2.leave the branch\n3.Clear map\n4.Add\n5.Remove\n6.Exit\nYour chose:");
                chose = Convert.ToInt32(Console.ReadLine());
                if (chose==1)
                {
                    Console.Write("Number:");
                    string my_chose = Console.ReadLine();
                    my_tree.map_in_my_tree.Add(my_chose);
                }
                else if (chose == 2)
                {
                    my_tree.map_in_my_tree.RemoveAt(my_tree.map_in_my_tree.Count-1);
                }
                else if (chose == 3)
                {
                    my_tree.map_in_my_tree.Clear();
                }
                else if (chose == 4 )
                {
                    Console.Write("Enter name: ");
                    string my_chose = Console.ReadLine();
                    Console.Write("Enter price: ");
                    int my_price = Convert.ToInt32(Console.ReadLine());
                    my_tree.Add(my_chose, my_price);
                }
                else if (chose == 5)
                {
                    my_tree.Remove();
                }
                else if (chose == 6)
                {
                    break;
                }
                Console.Clear();
            }
        }
    }


}
